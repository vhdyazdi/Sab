
import React, { useState, useEffect, useCallback, useRef } from 'react';
import type { Settings } from './types';
import { DEFAULT_SETTINGS, FONTS, INITIAL_MESSAGES } from './constants';
import SettingsPanel from './components/SettingsPanel';
import MessageOverlay from './components/MessageOverlay';
import ConsentModal from './components/ConsentModal';
import { PlayIcon, StopIcon, CogIcon, PauseIcon } from './components/icons';
import { exportSettings, importSettings } from './utils/file';

const App: React.FC = () => {
  const [settings, setSettings] = useState<Settings>(DEFAULT_SETTINGS);
  const [messages, setMessages] = useState<string[]>(INITIAL_MESSAGES);
  const [isRunning, setIsRunning] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [hasConsented, setHasConsented] = useState(false);

  const [currentMessage, setCurrentMessage] = useState<{ text: string; top: number; left: number } | null>(null);
  const [isMessageVisible, setIsMessageVisible] = useState(false);

  const messageIndexRef = useRef(0);
  // FIX: Use ReturnType<typeof setInterval> instead of NodeJS.Timeout for browser compatibility.
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  // FIX: Use ReturnType<typeof setTimeout> instead of NodeJS.Timeout for browser compatibility.
  const visibilityTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Load state from localStorage on initial render
  useEffect(() => {
    try {
      const savedSettings = localStorage.getItem('subliminalSettings');
      if (savedSettings) setSettings(JSON.parse(savedSettings));
      
      const savedMessages = localStorage.getItem('subliminalMessages');
      if (savedMessages) setMessages(JSON.parse(savedMessages));

      const savedConsent = localStorage.getItem('subliminalConsent');
      if (savedConsent) setHasConsented(JSON.parse(savedConsent));
    } catch (error) {
      console.error("Failed to load state from localStorage", error);
    }
  }, []);

  // Save state to localStorage whenever it changes
  useEffect(() => {
    try {
      localStorage.setItem('subliminalSettings', JSON.stringify(settings));
    } catch (error) {
      console.error("Failed to save settings to localStorage", error);
    }
  }, [settings]);

  useEffect(() => {
    try {
      localStorage.setItem('subliminalMessages', JSON.stringify(messages));
    } catch (error) {
      console.error("Failed to save messages to localStorage", error);
    }
  }, [messages]);
  
  useEffect(() => {
    try {
      localStorage.setItem('subliminalConsent', JSON.stringify(hasConsented));
    } catch (error) {
      console.error("Failed to save consent to localStorage", error);
    }
  }, [hasConsented]);

  const showNextMessage = useCallback(() => {
    if (messages.length === 0) return;

    if (settings.randomOrder) {
      const randomIndex = Math.floor(Math.random() * messages.length);
      messageIndexRef.current = randomIndex;
    } else {
      messageIndexRef.current = (messageIndexRef.current + 1) % messages.length;
    }
    
    const text = messages[messageIndexRef.current];
    let top = settings.positionY;
    let left = settings.positionX;

    if (settings.randomPosition) {
        top = Math.random() * 100;
        left = Math.random() * 100;
    }

    setCurrentMessage({ text, top, left });
    setIsMessageVisible(true);

    if (visibilityTimeoutRef.current) clearTimeout(visibilityTimeoutRef.current);
    visibilityTimeoutRef.current = setTimeout(() => {
      setIsMessageVisible(false);
    }, settings.duration);
  }, [messages, settings]);

  const clearTimers = () => {
    if (timerRef.current) clearInterval(timerRef.current);
    if (visibilityTimeoutRef.current) clearTimeout(visibilityTimeoutRef.current);
    timerRef.current = null;
    visibilityTimeoutRef.current = null;
  };

  useEffect(() => {
    if (isRunning && !isPaused) {
      clearTimers();
      showNextMessage(); // Show first message immediately
      timerRef.current = setInterval(showNextMessage, settings.interval);
    } else {
      clearTimers();
    }
    return clearTimers;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isRunning, isPaused, settings, showNextMessage]);

  const handleStart = () => {
    if (!hasConsented) return;
    setIsRunning(true);
    setIsPaused(false);
    setShowSettings(false);
  };

  const handlePause = () => {
    setIsPaused(!isPaused);
  };
  
  const handleStop = () => {
    setIsRunning(false);
    setIsPaused(false);
    setIsMessageVisible(false);
    setCurrentMessage(null);
  };

  const handleConsent = () => {
    setHasConsented(true);
  };
  
  const handleExport = () => {
    exportSettings({ settings, messages });
  };
  
  const handleImport = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const data = await importSettings(event);
    if (data) {
      if (data.settings) setSettings(data.settings);
      if (data.messages) setMessages(data.messages);
      alert("تنظیمات با موفقیت وارد شد!");
    }
  };

  return (
    <div className="min-h-screen bg-gray-900 text-gray-200 flex flex-col items-center justify-center p-4 relative font-[Vazirmatn]">
      {!hasConsented && <ConsentModal onConfirm={handleConsent} />}
      
      {currentMessage && <MessageOverlay message={currentMessage} isVisible={isMessageVisible} settings={settings} />}

      <div className="absolute top-4 right-4 z-20">
        <button
          onClick={() => setShowSettings(!showSettings)}
          className="p-3 bg-gray-800/80 hover:bg-indigo-600 rounded-full transition-colors duration-200 shadow-lg backdrop-blur-sm"
          aria-label="تنظیمات"
          disabled={!hasConsented}
        >
          <CogIcon className="w-6 h-6" />
        </button>
      </div>

      <div className="text-center z-10">
        <h1 className="text-4xl md:text-6xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 to-purple-500 mb-4">
          پیام‌های سابلیمینال
        </h1>
        <p className="text-lg text-gray-400 mb-8">ذهن خود را برای موفقیت برنامه‌ریزی کنید.</p>
        
        {!isRunning && (
            <div className="flex flex-col items-center">
                <button
                    onClick={handleStart}
                    disabled={!hasConsented || messages.length === 0}
                    className="flex items-center gap-3 bg-indigo-600 hover:bg-indigo-500 disabled:bg-gray-600 disabled:cursor-not-allowed text-white font-bold py-3 px-8 rounded-full transition-transform transform hover:scale-105 duration-300 shadow-lg shadow-indigo-600/30 text-xl"
                >
                    <PlayIcon className="w-6 h-6" />
                    <span>شروع</span>
                </button>
                {!hasConsented && <p className="mt-4 text-yellow-400">لطفاً برای شروع، با شرایط استفاده موافقت کنید.</p>}
                {hasConsented && messages.length === 0 && <p className="mt-4 text-yellow-400">لطفاً ابتدا از بخش تنظیمات چند پیام اضافه کنید.</p>}
            </div>
        )}
      </div>

      {isRunning && (
        <div className="fixed bottom-5 left-1/2 -translate-x-1/2 z-20 flex items-center gap-4 bg-gray-800/80 p-3 rounded-full shadow-lg backdrop-blur-sm">
          <button onClick={handlePause} className="p-3 hover:bg-gray-700 rounded-full transition-colors">
            {isPaused ? <PlayIcon className="w-6 h-6 text-green-400" /> : <PauseIcon className="w-6 h-6 text-yellow-400" />}
          </button>
          <div className="w-px h-8 bg-gray-600"></div>
          <button onClick={handleStop} className="p-3 hover:bg-gray-700 rounded-full transition-colors">
            <StopIcon className="w-6 h-6 text-red-400" />
          </button>
        </div>
      )}

      <SettingsPanel
        isOpen={showSettings}
        onClose={() => setShowSettings(false)}
        settings={settings}
        setSettings={setSettings}
        messages={messages}
        setMessages={setMessages}
        onExport={handleExport}
        onImport={handleImport}
      />
    </div>
  );
};

export default App;
