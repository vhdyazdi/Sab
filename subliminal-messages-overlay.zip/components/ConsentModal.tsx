
import React from 'react';

interface ConsentModalProps {
  onConfirm: () => void;
}

const ConsentModal: React.FC<ConsentModalProps> = ({ onConfirm }) => {
  return (
    <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4">
      <div className="bg-gray-800 rounded-lg shadow-xl max-w-lg w-full p-6 md:p-8 text-center border border-gray-700">
        <h2 className="text-2xl font-bold text-yellow-400 mb-4">هشدار و رضایت‌نامه</h2>
        <p className="text-gray-300 mb-6 text-right leading-relaxed">
          این برنامه متن‌های نیمه‌مخفی (سابلیمینال) را به‌طور دوره‌ای روی صفحه نمایش می‌دهد. این پیام‌ها کوتاه و تقریباً نامرئی هستند و برای تأثیرگذاری روی ضمیر ناخودآگاه طراحی شده‌اند.
          <br/><br/>
          با زدن دکمه «موافقم»، شما تأیید می‌کنید که از این عملکرد آگاه هستید و می‌پذیرید که در هر زمان می‌توانید سرویس را متوقف کرده و کنترل کامل بر آن دارید.
        </p>
        <button
          onClick={onConfirm}
          className="w-full bg-indigo-600 hover:bg-indigo-500 text-white font-bold py-3 px-6 rounded-lg transition-colors duration-200"
        >
          موافقم و ادامه می‌دهم
        </button>
      </div>
    </div>
  );
};

export default ConsentModal;
