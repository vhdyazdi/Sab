
import React, { useState } from 'react';
import type { Settings } from '../types';
import { FONTS, DEFAULT_SETTINGS } from '../constants';
import { CloseIcon, PlusIcon, TrashIcon, DownloadIcon, UploadIcon } from './icons';

interface SettingsPanelProps {
  isOpen: boolean;
  onClose: () => void;
  settings: Settings;
  setSettings: React.Dispatch<React.SetStateAction<Settings>>;
  messages: string[];
  setMessages: React.Dispatch<React.SetStateAction<string[]>>;
  onExport: () => void;
  onImport: (event: React.ChangeEvent<HTMLInputElement>) => void;
}

const SettingsPanel: React.FC<SettingsPanelProps> = ({
  isOpen,
  onClose,
  settings,
  setSettings,
  messages,
  setMessages,
  onExport,
  onImport
}) => {
  const [newMessage, setNewMessage] = useState('');

  const handleSettingChange = <K extends keyof Settings,>(key: K, value: Settings[K]) => {
    // Validation
    if (key === 'duration' && (Number(value) < 50 || Number(value) > 2000)) {
        alert("مدت زمان نمایش باید بین ۵۰ تا ۲۰۰۰ میلی‌ثانیه باشد.");
        return;
    }
    if (key === 'interval' && Number(value) < 100) {
        alert("فاصله زمانی باید حداقل ۱۰۰ میلی‌ثانیه باشد.");
        return;
    }

    setSettings(prev => ({ ...prev, [key]: value }));
  };

  const addMessage = () => {
    if (newMessage.trim()) {
      setMessages([...messages, newMessage.trim()]);
      setNewMessage('');
    }
  };

  const deleteMessage = (index: number) => {
    setMessages(messages.filter((_, i) => i !== index));
  };
  
  const resetToDefaults = () => {
      if(window.confirm("آیا مطمئن هستید که می‌خواهید تمام تنظیمات را به حالت پیش‌فرض بازگردانید؟")){
          setSettings(DEFAULT_SETTINGS);
          // Not resetting messages by default
      }
  };

  return (
    <>
      <div 
        className={`fixed inset-0 bg-black/60 z-30 transition-opacity ${isOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}
        onClick={onClose}
      ></div>
      <div
        className={`fixed top-0 right-0 h-full w-full max-w-lg bg-gray-800 shadow-2xl z-40 transform transition-transform duration-300 ease-in-out ${
          isOpen ? 'translate-x-0' : 'translate-x-full'
        } flex flex-col`}
      >
        <header className="flex items-center justify-between p-4 border-b border-gray-700">
          <h2 className="text-2xl font-bold text-indigo-400">تنظیمات</h2>
          <button onClick={onClose} className="p-2 rounded-full hover:bg-gray-700">
            <CloseIcon className="w-6 h-6" />
          </button>
        </header>

        <div className="flex-grow p-6 overflow-y-auto">
          {/* Live Preview */}
          <div className="mb-8 p-4 rounded-lg bg-gray-900 relative h-48 flex items-center justify-center overflow-hidden">
            <span
              style={{
                fontFamily: settings.font,
                fontSize: `${settings.size}px`,
                color: settings.color,
                opacity: settings.opacity,
                textShadow: '1px 1px 3px rgba(0,0,0,0.5)'
              }}
              className="transition-all"
            >
              پیش‌نمایش متن
            </span>
          </div>

          {/* Messages */}
          <div className="space-y-4 mb-8">
            <h3 className="text-xl font-semibold border-b-2 border-indigo-500 pb-2">پیام‌ها</h3>
            <div className="max-h-48 overflow-y-auto bg-gray-900 p-2 rounded-md space-y-2">
                {messages.map((msg, index) => (
                    <div key={index} className="flex items-center justify-between bg-gray-700 p-2 rounded">
                        <span className="flex-1 truncate">{msg}</span>
                        <button onClick={() => deleteMessage(index)} className="p-1 text-red-400 hover:text-red-300">
                            <TrashIcon className="w-5 h-5" />
                        </button>
                    </div>
                ))}
                {messages.length === 0 && <p className="text-gray-500 text-center p-4">هنوز پیامی اضافه نشده است.</p>}
            </div>
            <div className="flex gap-2">
                <input
                    type="text"
                    value={newMessage}
                    onChange={(e) => setNewMessage(e.target.value)}
                    placeholder="پیام جدید خود را وارد کنید..."
                    className="flex-grow bg-gray-700 border border-gray-600 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    onKeyDown={(e) => e.key === 'Enter' && addMessage()}
                />
                <button onClick={addMessage} className="p-2 bg-indigo-600 rounded-md hover:bg-indigo-500">
                    <PlusIcon className="w-6 h-6" />
                </button>
            </div>
          </div>

          {/* Appearance */}
          <div className="space-y-4 mb-8">
             <h3 className="text-xl font-semibold border-b-2 border-indigo-500 pb-2">ظاهر</h3>
              <div>
                <label className="block mb-2">فونت</label>
                <select value={settings.font} onChange={(e) => handleSettingChange('font', e.target.value)} className="w-full bg-gray-700 border border-gray-600 rounded-md px-3 py-2">
                  {FONTS.map(font => <option key={font.value} value={font.value}>{font.name}</option>)}
                </select>
              </div>
              <div className="flex gap-4">
                <div className="flex-1">
                  <label className="block mb-2">اندازه متن ({settings.size}px)</label>
                  <input type="range" min="8" max="48" value={settings.size} onChange={(e) => handleSettingChange('size', parseInt(e.target.value, 10))} className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer" />
                </div>
                <div className="flex-1">
                  <label className="block mb-2">شفافیت ({Math.round(settings.opacity * 100)}%)</label>
                  <input type="range" min="0.01" max="1" step="0.01" value={settings.opacity} onChange={(e) => handleSettingChange('opacity', parseFloat(e.target.value))} className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer" />
                </div>
              </div>
              <div>
                <label className="block mb-2">رنگ متن</label>
                <div className="flex items-center gap-2 bg-gray-700 border border-gray-600 rounded-md p-2">
                    <input type="color" value={settings.color} onChange={(e) => handleSettingChange('color', e.target.value)} className="w-8 h-8 p-0 border-none bg-transparent cursor-pointer" />
                    <span className="font-mono">{settings.color}</span>
                </div>
              </div>
          </div>

          {/* Timing */}
          <div className="space-y-4 mb-8">
            <h3 className="text-xl font-semibold border-b-2 border-indigo-500 pb-2">زمان‌بندی</h3>
            <div>
              <label className="block mb-2">فاصله بین پیام‌ها (میلی‌ثانیه)</label>
              <input type="number" min="100" step="100" value={settings.interval} onChange={(e) => handleSettingChange('interval', parseInt(e.target.value, 10))} className="w-full bg-gray-700 border border-gray-600 rounded-md px-3 py-2" />
            </div>
            <div>
              <label className="block mb-2">مدت زمان نمایش (میلی‌ثانیه)</label>
              <input type="number" min="50" max="2000" step="50" value={settings.duration} onChange={(e) => handleSettingChange('duration', parseInt(e.target.value, 10))} className="w-full bg-gray-700 border border-gray-600 rounded-md px-3 py-2" />
            </div>
          </div>

          {/* Position */}
          <div className="space-y-4">
            <h3 className="text-xl font-semibold border-b-2 border-indigo-500 pb-2">موقعیت</h3>
             <div className="flex items-center justify-between bg-gray-700 p-3 rounded-md">
                <label htmlFor="randomOrder">نمایش تصادفی پیام‌ها</label>
                <input id="randomOrder" type="checkbox" checked={settings.randomOrder} onChange={(e) => handleSettingChange('randomOrder', e.target.checked)} className="w-5 h-5 text-indigo-600 bg-gray-900 border-gray-600 rounded focus:ring-indigo-500" />
            </div>
            <div className="flex items-center justify-between bg-gray-700 p-3 rounded-md">
                <label htmlFor="randomPosition">موقعیت تصادفی روی صفحه</label>
                <input id="randomPosition" type="checkbox" checked={settings.randomPosition} onChange={(e) => handleSettingChange('randomPosition', e.target.checked)} className="w-5 h-5 text-indigo-600 bg-gray-900 border-gray-600 rounded focus:ring-indigo-500" />
            </div>
            {!settings.randomPosition && (
              <div className="p-3 bg-gray-700 rounded-md">
                <p className="mb-2">موقعیت ثابت</p>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { y: 10, x: 10, name: 'بالا-چپ' }, { y: 10, x: 50, name: 'بالا-وسط' }, { y: 10, x: 90, name: 'بالا-راست' },
                    { y: 50, x: 10, name: 'وسط-چپ' }, { y: 50, x: 50, name: 'وسط' }, { y: 50, x: 90, name: 'وسط-راست' },
                    { y: 90, x: 10, name: 'پایین-چپ' }, { y: 90, x: 50, name: 'پایین-وسط' }, { y: 90, x: 90, name: 'پایین-راست' },
                  ].map(pos => (
                    <button
                      key={pos.name}
                      onClick={() => {
                          handleSettingChange('positionX', pos.x);
                          handleSettingChange('positionY', pos.y);
                      }}
                      className={`p-2 rounded text-sm ${settings.positionX === pos.x && settings.positionY === pos.y ? 'bg-indigo-600' : 'bg-gray-600 hover:bg-gray-500'}`}
                    >
                      {pos.name}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
        
        <footer className="p-4 border-t border-gray-700 flex flex-wrap gap-2 justify-between">
            <button onClick={resetToDefaults} className="px-4 py-2 bg-red-600 hover:bg-red-500 rounded-md text-sm">بازنشانی به پیش‌فرض</button>
            <div className="flex gap-2">
                <button onClick={onExport} className="flex items-center gap-2 px-4 py-2 bg-green-600 hover:bg-green-500 rounded-md text-sm">
                    <DownloadIcon className="w-4 h-4" />
                    خروجی
                </button>
                <label className="flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-500 rounded-md text-sm cursor-pointer">
                    <UploadIcon className="w-4 h-4" />
                    ورودی
                    <input type="file" accept=".json" onChange={onImport} className="hidden" />
                </label>
            </div>
        </footer>
      </div>
    </>
  );
};

export default SettingsPanel;
