
import React from 'react';
import type { Settings } from '../types';

interface MessageOverlayProps {
  message: { text: string; top: number; left: number };
  isVisible: boolean;
  settings: Settings;
}

const MessageOverlay: React.FC<MessageOverlayProps> = ({ message, isVisible, settings }) => {
  const style: React.CSSProperties = {
    position: 'fixed',
    top: `${message.top}%`,
    left: `${message.left}%`,
    transform: 'translate(-50%, -50%)',
    fontFamily: settings.font,
    fontSize: `${settings.size}px`,
    color: settings.color,
    opacity: isVisible ? settings.opacity : 0,
    textShadow: '1px 1px 3px rgba(0,0,0,0.7)',
    transitionProperty: 'opacity',
    transitionDuration: `${settings.duration / 2}ms`, // Use half duration for fade in/out
    transitionTimingFunction: 'ease-in-out',
    pointerEvents: 'none',
    whiteSpace: 'nowrap',
  };

  return <div style={style}>{message.text}</div>;
};

export default MessageOverlay;
