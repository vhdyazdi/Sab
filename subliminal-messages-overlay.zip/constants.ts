
import type { Settings } from './types';

export const INITIAL_MESSAGES: string[] = [
  'من با اعتماد به نفس هستم',
  'نفس من عمیق و آرام است',
  'من قادر و ارزشمندم',
  'من می‌توانم تغییرات مثبت ایجاد کنم'
];

export const DEFAULT_SETTINGS: Settings = {
  font: "'Vazirmatn', sans-serif",
  size: 14,
  color: '#FFFFFF',
  opacity: 0.15,
  interval: 5000,
  duration: 400,
  randomPosition: false,
  randomOrder: false,
  positionX: 10,
  positionY: 10,
};

export const FONTS = [
  { name: 'پیش‌فرض (وزیرمتن)', value: "'Vazirmatn', sans-serif" },
  { name: 'Roboto', value: "'Roboto', sans-serif" },
  { name: 'Lato', value: "'Lato', sans-serif" },
  { name: 'Arial', value: 'Arial, sans-serif' },
  { name: 'Verdana', value: 'Verdana, sans-serif' },
];
