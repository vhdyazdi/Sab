
export interface Settings {
  font: string;
  size: number;
  color: string;
  opacity: number;
  interval: number;
  duration: number;
  randomPosition: boolean;
  randomOrder: boolean;
  positionX: number; // percentage
  positionY: number; // percentage
}
