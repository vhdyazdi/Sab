
// FIX: Import ChangeEvent type from React to resolve namespace error.
import type { ChangeEvent } from 'react';
import type { Settings } from '../types';

interface ExportData {
    settings: Settings;
    messages: string[];
}

export const exportSettings = (data: ExportData) => {
    const jsonString = `data:text/json;charset=utf-8,${encodeURIComponent(
        JSON.stringify(data, null, 2)
    )}`;
    const link = document.createElement("a");
    link.href = jsonString;
    link.download = "subliminal-settings.json";
    link.click();
};

export const importSettings = (event: ChangeEvent<HTMLInputElement>): Promise<ExportData | null> => {
    return new Promise((resolve, reject) => {
        const file = event.target.files?.[0];
        if (!file) {
            resolve(null);
            return;
        }

        const reader = new FileReader();
        reader.onload = (e) => {
            try {
                const text = e.target?.result;
                if (typeof text === 'string') {
                    const data: ExportData = JSON.parse(text);
                    // Basic validation
                    if (data.settings && data.messages) {
                        resolve(data);
                    } else {
                        alert("فایل نامعتبر است. ساختار فایل صحیح نیست.");
                        resolve(null);
                    }
                }
            } catch (error) {
                console.error("Error parsing JSON file", error);
                alert("خطا در پردازش فایل. لطفاً از صحت فایل JSON اطمینان حاصل کنید.");
                reject(error);
            }
        };
        reader.onerror = (error) => {
            console.error("Error reading file", error);
            alert("خطا در خواندن فایل.");
            reject(error);
        }
        reader.readAsText(file);
    });
};
